# *Демонстрационный экзамен 09.02.06 2025*

### **[Задание](https://github.com/damh66/demo2025/blob/main/%D0%9A%D0%9E%D0%94%2009.02.06-1-2025%20%D0%A2%D0%BE%D0%BC%201%20(%D1%81%D0%BE%D0%BA%D1%80).pdf)**

#

#

### Решение модулей

- **[Модуль 1](https://github.com/damh66/demo2025/tree/main/module1)**

- **[Модуль 2](https://github.com/damh66/demo2025/tree/main/module2)**

#

#

### Используемые операционные системы

- **EcoRouter** (**[Документация](https://docs.rdpin.ru/EcoRouter-UserGuide.pdf)**, **[Образ](https://disk.yandex.ru/d/_0GFwvAGVm4Iow)**)
   > *HQ-RTR*
   >
   > *BR-RTR*

- **Alt Linux Server** (**[Документация](https://docs.altlinux.org/ru-RU/alt-server/10.1/html/alt-server/index.html)**, **[Образ](https://www.basealt.ru/alt-server/download)**)
   > *ISP*
   >
   > *HQ-SRV*
   >
   > *BR-SRV*

- **Alt Linux Workstation** (**[Документация](https://docs.altlinux.org/ru-RU/alt-workstation/10.1/html/alt-workstation/index.html)**, **[Образ](https://www.basealt.ru/alt-workstation/download)**)
   > *HQ-CLI*
 

#
